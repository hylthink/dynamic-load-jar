//
//  CocoDataBlock.h
//  configSDK
//
//  Created by yinchong on 13-12-5.
//  Copyright (c) 2013年 yinchong. All rights reserved.
//

#ifndef CocoDataSDK_CocoDataBlock_h
#define CocoDataSDK_CocoDataBlock_h


/**
 *在线配置的block，当配置发生变化时回调
 */
typedef void (^CKCocoConfigChangedBlock)();


#endif
