var searchData=
[
  ['dictionaryforproperty_3adefaultvalue_3a',['dictionaryForProperty:defaultValue:',['../interface_c_k_coco_data.html#a87fc9f060557b8e6f245b5cfe45e8c2d',1,'CKCocoData']]],
  ['doubleforproperty_3adefaultvalue_3a',['doubleForProperty:defaultValue:',['../interface_c_k_coco_data.html#af8bdad75c57e944ef74d9a67f37549b7',1,'CKCocoData']]]
];
