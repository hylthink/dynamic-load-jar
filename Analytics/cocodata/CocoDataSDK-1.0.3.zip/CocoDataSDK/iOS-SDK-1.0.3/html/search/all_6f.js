var searchData=
[
  ['onconfigchanged_3a',['onConfigChanged:',['../interface_c_k_coco_data.html#a3baefa9e984c9fbcee112af6e5ae9603',1,'CKCocoData']]]
];
