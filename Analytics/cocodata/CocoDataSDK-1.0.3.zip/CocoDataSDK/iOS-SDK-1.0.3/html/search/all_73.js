var searchData=
[
  ['stringforproperty_3adefaultvalue_3a',['stringForProperty:defaultValue:',['../interface_c_k_coco_data.html#abb2a36b50ba5aaa888c8b6882ca56b5e',1,'CKCocoData']]],
  ['syncconfig',['syncConfig',['../interface_c_k_coco_data.html#adfab100e5cdc13aad03f63d1dc91532f',1,'CKCocoData']]],
  ['syncconfig_3a',['syncConfig:',['../interface_c_k_coco_data4_s_d_k.html#a158da2bc54bebe3036a8df2251911c44',1,'CKCocoData4SDK']]]
];
