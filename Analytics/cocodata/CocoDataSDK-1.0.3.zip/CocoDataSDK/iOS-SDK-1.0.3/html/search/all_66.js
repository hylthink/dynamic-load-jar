var searchData=
[
  ['floatforproperty_3adefaultvalue_3a',['floatForProperty:defaultValue:',['../interface_c_k_coco_data.html#abf813383f8165b43ecec3fe4b3f7cf6c',1,'CKCocoData']]]
];
