var searchData=
[
  ['event_3a',['event:',['../interface_c_k_coco_data.html#a1b970b7308862ba75800933f6c801aa1',1,'CKCocoData']]],
  ['event_3alabel_3a',['event:label:',['../interface_c_k_coco_data.html#a2a4c98dbe1ff37de27aa40609730ebf6',1,'CKCocoData']]],
  ['event_3alabel_3aparameters_3a',['event:label:parameters:',['../interface_c_k_coco_data.html#aca475319556181452f630d4767db1b9d',1,'CKCocoData']]],
  ['event_3aparameters_3a',['event:parameters:',['../interface_c_k_coco_data.html#a474a061e60d68fea692a80cd56cb5508',1,'CKCocoData']]]
];
