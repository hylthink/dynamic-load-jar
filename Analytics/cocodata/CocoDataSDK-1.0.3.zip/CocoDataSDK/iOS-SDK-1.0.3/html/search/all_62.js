var searchData=
[
  ['boolforproperty_3adefaultvalue_3a',['boolForProperty:defaultValue:',['../interface_c_k_coco_data.html#aa5fed770d40fdd7166b884a6f4db6aaf',1,'CKCocoData']]]
];
