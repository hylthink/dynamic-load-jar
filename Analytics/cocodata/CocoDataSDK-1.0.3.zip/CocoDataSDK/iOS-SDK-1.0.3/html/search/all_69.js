var searchData=
[
  ['initwithappid_3a',['initWithAppId:',['../interface_c_k_coco_data.html#a59d44f65c307a99d6864913115393755',1,'CKCocoData::initWithAppId:()'],['../interface_c_k_coco_data4_s_d_k.html#ad39ac1fae6b5138bea3df4e75c3b8798',1,'CKCocoData4SDK::initWithAppId:()']]],
  ['initwithappid_3areportpolicy_3achannel_3a',['initWithAppId:reportPolicy:channel:',['../interface_c_k_coco_data.html#afafeebd067041179749c0d1d93db020f',1,'CKCocoData::initWithAppId:reportPolicy:channel:()'],['../interface_c_k_coco_data4_s_d_k.html#a18ab79c1cbbd5d9497c8ca5bcff0aec4',1,'CKCocoData4SDK::initWithAppId:reportPolicy:channel:()']]],
  ['integerforproperty_3adefaultvalue_3a',['integerForProperty:defaultValue:',['../interface_c_k_coco_data.html#ae3e8f5e55f3ff0eedea0fe485a36971d',1,'CKCocoData']]]
];
