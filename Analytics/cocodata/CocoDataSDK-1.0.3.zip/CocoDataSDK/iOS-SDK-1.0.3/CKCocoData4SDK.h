//
//  CocoData4SDK.h
//  configSDK
//
//  Created by yinchong on 13-12-4.
//  Copyright (c) 2013年 yinchong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CKCocoDataBlock.h"

/**
 * 如果你开发的是一个app，请使用CKCocoData类中的API；<br>
 * 如果你开发的是一个sdk，请使用CKCocoData4SDK类中的相关API；
 */
@interface CKCocoData4SDK : NSObject

/**
 *	@method	initWithAppId 初始化SDK
 *	@param 	appId         分配的appId
 */
+ (void) initWithAppId:(NSString *)appId;

/**
 *	@method	initWithAppId:reportPolicy:channel 初始化SDK
 *	@param 	appId         分配的appId
 *	@param 	policy        数据发送策略 可选值：BATCH,REALTIME  默认为REALTIME
 *	@param 	channel       渠道
 */
+ (void) initWithAppId:(NSString *)appId reportPolicy:(NSString *)policy channel:(NSString *)channel;

/***********************数据跟踪相关API*************************/

/**
 *	@method	appId:event
 *  自定义事件(只统计事件ID)
 *	@param 	appId    	分配给开发者的appId
 *	@param 	eventId 	事件名称（自定义）
 */
+ (void)appId:(NSString *)appId event:(NSString *)eventId;

/**
 *	@method	appId:event:label:
 *  自定义事件(可用标签来区别同一个事件的不同应用场景)
 *
 *	@param 	appId    	分配给开发者的appId
 *	@param 	eventId 	事件名称（自定义）
 *	@param 	eventLabel 	事件标签（自定义）
 */
+ (void)appId:(NSString *)appId event:(NSString *)eventId label:(NSString *)eventLabel;

/**
 *	@method	appId:event:label:parameters
 *  自定义事件(事件可带多个参数)
 *
 *	@param 	appId    	分配给开发者的appId
 *	@param 	eventId 	事件名称（自定义）
 *	@param 	parameters 	事件参数 (key只支持NSString, value支持NSString和NSNumber)
 */
+ (void)appId:(NSString *)appId event:(NSString *)eventId parameters:(NSDictionary *)parameters;

/**
 *	@method	appId:event:label:parameters
 *  自定义事件(事件标签可带多个参数)
 *
 *	@param 	appId    	分配给开发者的appId
 *	@param 	eventId 	事件名称（自定义）
 *	@param 	eventLabel 	事件标签（自定义）
 *	@param 	parameters 	事件参数 (key只支持NSString, value支持NSString和NSNumber)
 */
+ (void)appId:(NSString *)appId event:(NSString *)eventId label:(NSString *)eventLabel parameters:(NSDictionary *)parameters;

/**
 *	@method	appId:viewBegin
 *  开始跟踪某一页面，记录页面打开时间，建议在viewWillAppear或者viewDidAppear方法里调用
 *	@param 	appId    	分配给开发者的appId
 *	@param 	viewName 	页面名称（自定义）
 */
+ (void)appId:(NSString *)appId viewBegin:(NSString *)viewName;

/**
 *	@method	appId:viewEnd
 *  结束某一页面的跟踪，记录页面的关闭时间，此方法与viewBegin方法结对使用，建议在viewWillDisappear或者viewDidDisappear方法里调用
 *	@param 	appId    	分配给开发者的appId
 *	@param 	viewName 	页面名称，请跟viewBegin方法的页面名称保持一致
 */
+ (void)appId:(NSString *)appId viewEnd:(NSString *)viewName;



/***********************获取配置相关API*************************/
/**
 * @method appId:onConfigChanged
 * 配置文件发生改变时的回调
 * @param 	appId    	分配给开发者的appId
 * @param 	block    	回到函数
 */
+ (void)appId:(NSString *)appId onConfigChanged:(CKCocoConfigChangedBlock)block;

/**
 * @method syncConfig
 * 同步配置文件，开发人员使用此函数可强制同步
 *	@param 	appId    	分配给开发者的appId
 */
+ (void) syncConfig:(NSString *) appId;

/**
 * @method appId:stringForProperty:defaultValue
 * 获取NSString类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (NSString *)appId:(NSString *)appId stringForProperty:(NSString *)name defaultValue:(NSString *)defValue;

/**
 * @method appId:integerForProperty:defaultValue
 * 获取NSInteger类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (NSInteger)appId:(NSString *)appId integerForProperty:(NSString *)name defaultValue:(NSInteger)defValue;


/**
 * @method appId:floatForProperty:defaultValue
 * 获取float类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (float)appId:(NSString *)appId floatForProperty:(NSString *)name defaultValue:(float)defValue;


/**
 * @method appId:doubleForProperty:defaultValue
 * 获取double类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (double)appId:(NSString *)appId doubleForProperty:(NSString *)name defaultValue:(double)defValue;


/**
 * @method appId:boolForProperty:defaultValue
 * 获取BOOL类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (BOOL)appId:(NSString *)appId boolForProperty:(NSString *)name defaultValue:(BOOL)defValue;

/**
 * @method appId:arrayForProperty:defaultValue
 * 获取NSArray类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (NSArray *)appId:(NSString *)appId arrayForProperty:(NSString *)name defaultValue:(NSArray *)defValue;

/**
 * @method appId:dictionaryForProperty:defaultValue
 * 获取NSDictionary类型参数值
 * @param appId    	分配给开发者的appId
 * @param name     配置项的名称，形式为:configName.property
 * @param defValue 如果取不到时的默认值
 */
+ (NSDictionary *)appId:(NSString *)appId dictionaryForProperty:(NSString *)name defaultValue:(NSDictionary *)defValue;


@end
