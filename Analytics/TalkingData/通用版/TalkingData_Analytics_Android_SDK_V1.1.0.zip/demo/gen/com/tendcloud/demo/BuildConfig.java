/** Automatically generated file. DO NOT MODIFY */
package com.tendcloud.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}