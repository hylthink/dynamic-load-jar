/** Automatically generated file. DO NOT MODIFY */
package com.punchbox.hailstonedemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}