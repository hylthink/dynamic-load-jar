package com.punchbox.hailstonedemo;

import com.punchbox.hailstone.HSAppInfo;
import com.punchbox.hailstone.HSFeedbackListener;
import com.punchbox.hailstone.HSInstance;
import com.punchbox.hailstone.HSRedeemListener;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;

public class MainActivity extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnInit       = (Button) this.findViewById(R.id.init);
        btnInit.setOnClickListener(this);
        Button btnRedeem = (Button) this.findViewById(R.id.redeem);
        btnRedeem.setOnClickListener(this);
        Button btnFeed = (Button) this.findViewById(R.id.feedback);
        btnFeed.setOnClickListener(this);
        Button btnRegister   = (Button) this.findViewById(R.id.register);
        btnRegister.setOnClickListener(this);
        Button btnCreateRole = (Button) this.findViewById(R.id.createrole);
        btnCreateRole.setOnClickListener(this);
        Button btnLogin      = (Button) this.findViewById(R.id.login);
        btnLogin.setOnClickListener(this);
        Button btnLogout     = (Button) this.findViewById(R.id.logout);
        btnLogout.setOnClickListener(this);
        Button btnAddCash    = (Button) this.findViewById(R.id.addcash);
        btnAddCash.setOnClickListener(this);
        Button btnShopTrade  = (Button) this.findViewById(R.id.trade);
        btnShopTrade.setOnClickListener(this);
        Button btnCustom     = (Button) this.findViewById(R.id.custom);
        btnCustom.setOnClickListener(this);
        Button btnUserLogin     = (Button) this.findViewById(R.id.userLogin);
        btnUserLogin.setOnClickListener(this);

        HSInstance.setIsLogEnabled(true);
    }

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.init:
			showInit();
			break;
		case R.id.redeem:
			redeemClicked();
			break;
		case R.id.feedback:
			feedbackClicked();
			break;
		case R.id.register:
			HSInstance.userRegister("TestAccountName", "TestAccountID");
			break;
		case R.id.createrole:
			HSInstance.createRole("TestAccountName", "TestRoleID", "TestRoleName", "Soldier");
			break;
		case R.id.login:
			HSInstance.roleLogin("TestAccountName", "TestRoleID", "TestRoleName", 20);
			break;
		case R.id.logout:
			HSInstance.roleLogout("TestAccountName", "TestRoleID", "TestRoleName", 20, 3600);
			break;
		case R.id.addcash:
			HSInstance.addCash("TestAccountName", 1, 2000, 500);
			break;
		case R.id.trade:
			HSInstance.shopTrade("TestAccountName", "201305201458345", "ItemCoin50", 6, 2, 1700, 300);
			break;
		case R.id.custom:
			HSInstance.customEvent("TestAccountName", "TestRoleID", "TestRoleName", "EventType1", "My Test Event");
			break;
		case R.id.userLogin:
			HSInstance.userLogin("TestAccountName", "TestAccountID");
			break;
		default:
			break;
		}
	}

	private void redeemClicked() {

		final EditText edText = new EditText(this);
		new AlertDialog.Builder(this)
		.setMessage("Redeem")
		.setView(edText)
		.setCancelable(false)
		.setPositiveButton("Sure", new DialogInterface.OnClickListener() {
			@Override
        	public void onClick(DialogInterface dialog, int whichButton) {
				String code = edText.getText().toString();
				HSInstance.redeemWithCode(code, new HSRedeemListener() {

					@Override
					public void RedeemFailed(int arg0, String arg1) {
						Log.d("HailstoneDemo", "Redeem Failed : " + arg1);
					}

					@Override
					public void RedeemSuccess(int arg0) {
						Log.d("HailstoneDemo", "Redeem Succeed: " + arg0);
					}

				});
				dialog.dismiss();
    		}
        })
        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
        })
		.create().show();
	}

	private void feedbackClicked() {

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	View view = View.inflate(this, R.layout.feedback_view, null);
    	builder.setCancelable(false);
    	final Dialog myDialog = builder.setView(view).create();
    	myDialog.show();
    	
    	// �رհ�ť�Ĵ��� 
    	Button button = (Button) myDialog.findViewById(R.id.cancelBtn);
        button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				myDialog.dismiss();
			}
        	
        });

        // ȷ����ť�Ĵ��� 
    	Button buttonConfirm = (Button) myDialog.findViewById(R.id.confirmBtn);
    	buttonConfirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
		    	EditText msgEdit = (EditText) myDialog.findViewById(R.id.msgEdit);
		    	EditText phoneEdit = (EditText) myDialog.findViewById(R.id.phoneEdit);
				String msg = msgEdit.getText().toString();
				String num = phoneEdit.getText().toString();
				HSInstance.userFeedback(msg, num, new HSFeedbackListener() {

					@Override
					public void FeedbackResult(int arg0, String arg1) {
						Log.d("HailstoneDemo", "Feedback result : " + arg1);
						myDialog.dismiss();
					}
				});
			}
        });
	}

	private void showInit() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	View view = View.inflate(this, R.layout.input_param, null);
    	builder.setCancelable(false);
    	final Dialog myDialog = builder.setView(view).create();
    	myDialog.show();

    	// �رհ�ť�Ĵ��� 
    	Button button = (Button) myDialog.findViewById(R.id.cancel);
        button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				myDialog.dismiss();
			}
        	
        });

        final TextView txtGameName = (TextView) (myDialog.findViewById(R.id.gameName));
        final TextView txtAppID = (TextView) (myDialog.findViewById(R.id.appid));
        final TextView txtChannelID = (TextView) (myDialog.findViewById(R.id.channelid));
        final TextView txtServerID = (TextView) (myDialog.findViewById(R.id.serverid));

        // ȷ����ť�Ĵ��� 
    	Button buttonConfirm = (Button) myDialog.findViewById(R.id.sure);
    	buttonConfirm.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				try {
					String gameName = txtGameName.getText().toString();
					String appID = txtAppID.getText().toString();
					String channelID = txtChannelID.getText().toString();
					String serverID = txtServerID.getText().toString();
			
					HSAppInfo appInfo = new HSAppInfo(MainActivity.this, gameName, appID, channelID, serverID);
					HSInstance.initialized(appInfo);
			
					HSInstance.startSession();
				} catch (Exception e) {
					e.printStackTrace();
				}

				myDialog.dismiss();
			}
        });
	}
}
